package com.lti.hrAppl.controllers;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.hibernate.HibernateException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import com.lti.hrAppl.services.CustomerServices;
import com.lti.hrAppl.services.SearchBus;
import com.lti.hrAppl.entities.BusDetails;
import com.lti.hrAppl.entities.BusRoute;
import com.lti.hrAppl.entities.Customer;
import com.lti.hrAppl.entities.TravelDayDetails;
import com.lti.hrAppl.exceptions.BusExceptions;

/*
 * Abstract Controller : Super Controller 
 * Multiaction Controller : Allows multiple methods. Here we will use this.
 * http://localhost:8081/SpringMVC_EmpWebVer5/listAll.do
 */

@RestController
@EnableWebMvc
public class ControlHrServices {
	
	@Autowired
	private SearchBus services;
	@Autowired
	private CustomerServices customer;
	
	@RequestMapping(value = "/listAll/search/{source}/{destination}/{day}",
			headers="Accept=application/json", method = RequestMethod.GET)
	public List<BusDetails> getSourceName(@PathVariable("source") String source,@PathVariable("destination") String destination,@PathVariable("day") String day) throws Exception {

		System.out.println("Reached here: " + source+destination+day); 
		List<BusDetails> busDetails=null;
		try {
		busDetails = services.findByRouteID(source,destination,day); 
		System.out.println(busDetails);
		}
		catch(HibernateException e)
		{
			System.out.println("Error in specified searched.");
		}
		return busDetails;		
	}
	

	@RequestMapping(value = "/listAll/route/{source}/{destination}",
			 method = RequestMethod.GET)
	public List<BusRoute> getRoute(@PathVariable("source") String source, @PathVariable("destination") String destination) throws BusExceptions{
		List<BusRoute> route= null;
		try {
		route= services.findBySourceName(source, destination);
		}
		catch(HibernateException e )
		{
			System.out.println("Some Error");
		}
		return route;
	}
	
	@RequestMapping(value = "/listAll/register/{email}/{phone}/{fullname}/{pass1}/{gender}",
		 method = RequestMethod.POST)
	public void saveCustomerDetails(@PathVariable("fullname") String custName,@PathVariable("gender") String gender,@PathVariable("phone") String mobileNo,@PathVariable("pass1") String password,@PathVariable("email") String email) throws BusExceptions {
		try {
			System.out.println("In services"+ email+ "  " +mobileNo + "  "+custName+ "  "+ password+"  "+ gender);
		customer.save(email, mobileNo,custName,password, gender);
		}
		catch(HibernateException e)
		{
			System.out.println("Error in registration");
			e.printStackTrace();
		}
		
	}
	
	
	
	/*public List<Customer> findByEmailId(@PathVariable String Email,@PathVariable String passw) throws BusExceptions {
		
			
		Email=Email+".com";
		System.out.println("Reached here: " + Email); 
		List<Customer> custom=null;
		try {
		custom = customer.findByEmailId(Email);
		
		
		}
		catch(HibernateException e)
		{
			System.out.println("Error in login credentials.");
		}
		System.out.println(custom);
		
		
		
		
		
	}*/
	
	
	
	@RequestMapping(value = "/listAll/loginn/{Email}/{passw}",headers="Accept=application/json",method = RequestMethod.POST)
	public Integer findByEmailId(@PathVariable String Email,@PathVariable String passw) throws BusExceptions {
		
		Integer data = 0;
		System.out.println("Reached here: " + Email); 
		List<Customer> custom=null;
		try {
		custom= customer.findByEmailId(Email);
		String email= custom.get(0).getEmail();
		String password= custom.get(0).getPassword();
		
		if(email==null) {
			System.out.println("user dosen't exist");
			data=0;
			
		}
		
		else {
			
			if(password.equals(passw)) {
				System.out.println("successful login");
				data=2;
			}
			
			else {
				System.out.println("username or password dosen't match");
				data=1;
			}
			
		}
		
		
		}
		catch(HibernateException e)
		{
			System.out.println("Error in login credentials.");
		}
		System.out.println(custom);
		
		return data;
		
	
		
		
	}
	
	
}
