package com.lti.hrAppl.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="boarding_Details")
public class BoardingDetails implements Serializable {
	
@Id
@Column(name="bus_no")
private String busNo;

@Column(name="boarding_point")
private String boardingPoint;

@Column(name="arrival_point")
private String arrivalPoint;

public String getBusNo() {
	return busNo;
}

public void setBusNo(String busNo) {
	this.busNo = busNo;
}

public String getBoardingPoint() {
	return boardingPoint;
}

public void setBoardingPoint(String boardingPoint) {
	this.boardingPoint = boardingPoint;
}

public String getArrivalPoint() {
	return arrivalPoint;
}

public void setArrivalPoint(String arrivalPoint) {
	this.arrivalPoint = arrivalPoint;
}


}
