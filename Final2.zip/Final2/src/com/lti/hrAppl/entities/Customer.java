package com.lti.hrAppl.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="customer")
public class Customer {

	
	@Id
	@Column(name = "email_Id")
	private String email;

	@Column(name = "password")
	private String password;

	@Column(name = "customer_Name")
	private String custName;

	@Column(name = "mobile_No")
	private String mobileNo;

	@Column(name = "customer_Gender")
	private String gender;
	
	@Override
	public String toString() {
		return "Customer [email=" + email + ", password=" + password + ", custName=" + custName + ", mobileNo="
				+ mobileNo + ", gender=" + gender + "]";
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	

}
