package com.lti.hrAppl.test;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.lti.hrAppl.daos.RouteDao;
import com.lti.hrAppl.daos.RouteDaoImpl;
import com.lti.hrAppl.entities.BusDetails;
import com.lti.hrAppl.entities.BusRoute;
import com.lti.hrAppl.entities.Customer;
import com.lti.hrAppl.entities.TravelDayDetails;
import com.lti.hrAppl.exceptions.BusExceptions;
import com.lti.hrAppl.services.CustomerServices;
import com.lti.hrAppl.services.SearchBus;

public class TestServices {

	public static void main(String[] args) throws BusExceptions {

		ApplicationContext ctx = new ClassPathXmlApplicationContext("springCore.xml");
		CustomerServices cs= (CustomerServices) ctx.getBean("customerServices");
		/*cs.save("nis123@gmail.com", "9870643211", "nihfi", "nj027", "Fmale");*/
		/*SearchBus services = (SearchBus) ctx.getBean("searchBus");
		 List<BusDetails> busDetails = services.findByRouteID("lonavala","mumbai", "Thursday"); 
		 for(BusDetails br : busDetails) {
			 System.out.println(br.getRouteId());
			 System.out.println(br.getProviderName());
		 }*/
		
		List<Customer> customer = cs.findByEmailId("nish123@gmail.com");
		for(Customer cus : customer) {
			 System.out.println(cus.getPassword());
			 System.out.println(cus.getMobileNo());
		 }
		 
	}

}
