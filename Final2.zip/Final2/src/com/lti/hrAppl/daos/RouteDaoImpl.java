package com.lti.hrAppl.daos;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.hibernate.Query;

import com.lti.hrAppl.exceptions.BusExceptions;
import com.lti.hrAppl.entities.*;


@Repository
public class RouteDaoImpl implements RouteDao {
	
	@Autowired
	private SessionFactory sessionFactory;


	@Override
	public BusRoute findById(String routeId)  throws BusExceptions {
		Session session = sessionFactory.openSession();
		BusRoute busRoute = (BusRoute) session.get(BusRoute.class, routeId);
		session.close();
		return busRoute;
	}

	@Override
	public List<BusRoute> findBySourceName(String source, String destination)  throws BusExceptions {
		List<BusRoute> busroute = null;
		Session session = sessionFactory.openSession();
		Query query = session.createQuery("from BusRoute br where br.source like :source and br.destination like :destination").setParameter("source",source).setParameter("destination",destination);
		busroute =  query.list();
		session.close();
		return busroute;
	}

	@Override
	public List<BusDetails> findById2(String routeId)  throws BusExceptions {
		List<BusDetails> busDetails=null;
		Session session = sessionFactory.openSession();
		Query query = session.createQuery("from BusDetails bd where bd.routeId like :routeId ").setParameter("routeId", "%"+routeId+"%");
		busDetails=query.list();
		session.close();
		return busDetails;
	}

	@Override
	public List<TravelDayDetails> findByBusNo(String busNo)  throws BusExceptions{
		
		List<TravelDayDetails> travelDayDetails = null;
		Session session = sessionFactory.openSession();
		Query query = session.createQuery("from TravelDayDetails tdd where tdd.busNo like :busNo").setParameter("busNo", "%"+busNo+"%");
		travelDayDetails = query.list();
		session.close();
		return travelDayDetails;
	}
	
	@Override
	public List<BusDetails> findByRouteID(String source, String destination, String day) throws BusExceptions
	{
		List<BusDetails> busdetails = null;
		Session session = sessionFactory.openSession();
		Query query = session.createQuery("from BusDetails bd where bd.routeId in(select br.routeId from BusRoute br where br.source like :source and br.destination like :destination) and bd.busNo in(select td.busNo from TravelDayDetails td where td.travelDay like :day)");
		query.setParameter("source", source );
		query.setParameter("destination", destination);
		query.setParameter("day", day);
		busdetails = query.list();
		session.close();
		return busdetails;

	}
}
