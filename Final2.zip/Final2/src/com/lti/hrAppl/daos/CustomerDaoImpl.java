package com.lti.hrAppl.daos;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lti.hrAppl.entities.Booking;
import com.lti.hrAppl.entities.Customer;
import com.lti.hrAppl.exceptions.BusExceptions;

@Repository
public class CustomerDaoImpl implements CustomerDao {

	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public void save(String custName, String mobileNo, String email, String password, String gender) {
		System.out.println(email+ "  " +mobileNo + "  "+custName+ "  "+ password+"  "+ gender);
		Customer customer = new Customer();
		customer.setEmail(email);
		customer.setMobileNo(mobileNo);
		customer.setCustName(custName);
		customer.setPassword(password);
		customer.setGender(gender);
		Session session = sessionFactory.openSession();
		Transaction tn = session.getTransaction();
			tn.begin();
			session.persist(customer);
			tn.commit();
		session.close();
		
	}

	@Override
	public List<Customer> findByEmailId(String email)  throws BusExceptions{
		List<Customer> customer= null;
		Session session= sessionFactory.openSession();
		Query query = session.createQuery("from Customer c where c.email like :email");
		query.setParameter("email", email);
		customer =query.list();
		session.close();
		return customer;
	}

}
