package com.lti.hrAppl.daos;

import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.hibernate.*;
import  com.lti.hrAppl.entities.BoardingDetails;
import  com.lti.hrAppl.entities.Booking;
import  com.lti.hrAppl.entities.SeatDetails;
import com.lti.hrAppl.exceptions.BusExceptions;


@Repository
public class SeatDetailsDaoImpl implements SeatDetailsDao{
	
	@Autowired
	private SessionFactory sessionFactory;
	
	@Override
	public List<SeatDetails> findByBookingId(Integer bookingId)  throws BusExceptions {
		Session session = sessionFactory.openSession();
		List<SeatDetails> seatDetails = null;
		Query query = session.createQuery("from SeatDetails sd where sd.bookingId like :bookingId").setParameter("bookingId", bookingId);
		seatDetails = query.list();
		session.close();
		return seatDetails;
	}
	
	
	@Override
	public void save(List<SeatDetails> seatDetails) {

		Session session = sessionFactory.openSession();
		Transaction tn = session.getTransaction();
		try {
			tn.begin();
			for(SeatDetails sd: seatDetails)
			{
				session.persist(sd);
			}
			tn.commit();
		} 
		catch (Exception e) {
			System.out.println("Error occurred : " + e.getMessage());
			tn.rollback();
		}
		session.close();
	}
	
	
	@Override
	public void deleteBooking(Integer bookingId)  throws BusExceptions{
		
		Session session = sessionFactory.openSession();
		Transaction t= session.getTransaction();
		t.begin();
		Query query = session.createQuery("delete from SeatDetails sd where sd.bookingId like :bookingId").setParameter("bookingId", bookingId);
		query.executeUpdate(); 
		t.commit();
		session.close();
		
	}

}
