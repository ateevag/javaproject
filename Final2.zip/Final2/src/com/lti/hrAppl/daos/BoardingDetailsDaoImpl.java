package com.lti.hrAppl.daos;

import java.sql.SQLException;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lti.hrAppl.entities.BoardingDetails;
import com.lti.hrAppl.entities.BusRoute;
import com.lti.hrAppl.exceptions.BusExceptions;

@Repository
public class BoardingDetailsDaoImpl implements BoardingDetailsDao {

	@Autowired
	private SessionFactory sessionFactory;
	
	@Override
	public List<String> findBoardingDetails(String busNo) throws BusExceptions{
		List<String> boardingDetails = null;
		Session session = sessionFactory.openSession();
		Query query = session.createQuery("select distinct boardingPoint from BoardingDetails bd where bd.busNo like :busNo").setParameter("busNo", busNo);
		boardingDetails = query.list();
		session.close();
		return boardingDetails;
	}
	
		@Override
		public List<String> findArrivalDetails(String busNo) throws BusExceptions{
			List<String> boardingDetails = null;
			
			Session session = sessionFactory.openSession();
			Query query = session.createQuery("select distinct arrivalPoint from BoardingDetails bd where bd.busNo like :busNo").setParameter("busNo", busNo);
			boardingDetails = query.list();
			session.close();
			return boardingDetails;
	}
	
	
	
}
