package com.lti.hrAppl.daos;

import java.util.List;
import  com.lti.hrAppl.entities.BoardingDetails;
import  com.lti.hrAppl.entities.SeatDetails;
import com.lti.hrAppl.exceptions.BusExceptions;

public interface SeatDetailsDao{

	List<SeatDetails> findByBookingId(Integer bookingId) throws BusExceptions;

	void save(List<SeatDetails> seatDetails1);
	void deleteBooking(Integer bookingId) throws BusExceptions;
	
}
