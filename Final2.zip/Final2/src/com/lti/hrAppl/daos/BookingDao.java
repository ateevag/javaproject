package com.lti.hrAppl.daos;

import java.util.List;

import com.lti.hrAppl.entities.Booking;
import com.lti.hrAppl.exceptions.BusExceptions;

public interface BookingDao {

	void save(Booking booking);
	Booking findByBookingId(Integer bookingId) throws BusExceptions;
	void updateBooking(Integer bookingId) throws BusExceptions;
	List<Booking> findByBusNoTravelDate(String busNo, String travelDate) throws BusExceptions;

}
