package com.lti.hrAppl.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.hrAppl.daos.*;
import com.lti.hrAppl.entities.*;
import com.lti.hrAppl.exceptions.BusExceptions;

@Service("searchBus")
public class SearchBusImpl implements SearchBus {

	@Autowired
	private RouteDao dao;
	
	
	@Override
	public void save(BusRoute route) throws BusExceptions {
			
	}

	@Override
	public BusRoute findById(String routeId) throws BusExceptions{
		
		return dao.findById(routeId);
	}

	@Override
	public List<BusRoute> findBySourceName(String source, String destination) throws BusExceptions{
		
		return dao.findBySourceName(source, destination);
	}

	@Override
	public List<BusDetails> findById2(String routeId) throws BusExceptions{
		
		return dao.findById2(routeId);
	}

	
	@Override
	public List<BusDetails> findByRouteID(String source, String destination, String day) throws BusExceptions{
	
		return dao.findByRouteID(source, destination, day);
	}

	@Override
	public List<TravelDayDetails> findByBusNo(String busNo) throws BusExceptions{
		
		return dao.findByBusNo(busNo);
	}

}
