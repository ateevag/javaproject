package com.lti.hrAppl.services;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.hrAppl.daos.BoardingDetailsDao;
import com.lti.hrAppl.entities.*;
import com.lti.hrAppl.exceptions.BusExceptions;

@Service("boardingServices")
public class BoardingServicesImpl implements BoardingServices {

	@Autowired
	private BoardingDetailsDao dao;

	@Override
	public List<String> findBoardingDetails(String busNo) throws BusExceptions{
		// TODO Auto-generated method stub
		return dao.findBoardingDetails(busNo);
	}

	@Override
	public List<String> findArrivalDetails(String busNo) throws BusExceptions {
		// TODO Auto-generated method stub
		return dao.findArrivalDetails(busNo);
	}
	
	

}
