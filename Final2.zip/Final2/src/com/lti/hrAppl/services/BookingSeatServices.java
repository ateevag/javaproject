package com.lti.hrAppl.services;

import java.util.List;

import com.lti.hrAppl.entities.Booking;
import com.lti.hrAppl.entities.SeatDetails;
import com.lti.hrAppl.exceptions.BusExceptions;

public interface BookingSeatServices {
	
	void save(Booking booking) throws BusExceptions;
	/*Booking findByBookingId(Integer bookingId); throws BusExceptions*/
	void updateBooking(Integer bookingId) throws BusExceptions;
	List<Booking> findByBusNoTravelDate(String busNo, String travelDate) throws BusExceptions;

	List<SeatDetails> findByBookingId(Integer bookingId) throws BusExceptions;
	void save(List<SeatDetails> seatDetails1) throws BusExceptions;
	void deleteBooking(Integer bookingId) throws BusExceptions;
}
