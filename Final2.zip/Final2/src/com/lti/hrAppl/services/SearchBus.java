package com.lti.hrAppl.services;

import java.util.List;

import com.lti.hrAppl.entities.BusDetails;
import com.lti.hrAppl.entities.BusRoute;
import com.lti.hrAppl.entities.TravelDayDetails;
import com.lti.hrAppl.exceptions.BusExceptions;

public interface SearchBus {

	void save(BusRoute route) throws BusExceptions;
	BusRoute findById(String routeId) throws BusExceptions;
	List<BusRoute> findBySourceName(String source, String destination) throws BusExceptions;
	List<BusDetails> findById2(String routeId) throws BusExceptions;
	List<BusDetails> findByRouteID(String source, String destination, String day) throws BusExceptions;
	List<TravelDayDetails> findByBusNo(String busNo) throws BusExceptions;
	
}
