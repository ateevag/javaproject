var webmodule = angular.module("webmodule", ['ngRoute']);

webmodule.config(

    function ($routeProvider) {
        $routeProvider

            .when('/home', {
                templateUrl: 'pages/home.html',
                controller: 'myCtrl'
            })

            .when('/about', {
                templateUrl: 'pages/about.html',
                controller: 'myCtrl'
            })

            .when('/service', {
                templateUrl: 'pages/service.html',
                controller: 'myCtrl'
            })

            .when('/faq', {
                templateUrl: 'pages/faq.html',
                controller: 'myCtrl'
            })

            .when('/tnc', {
                templateUrl: 'pages/tnc.html',
                controller: 'myCtrl'
            })

            .when('/view', {
                templateUrl: 'pages/viewticket.html',
                controller: 'myCtrl'
            })
            
            .when('/busdetails', {
             templateUrl: 'pages/busdetails.html',
            	 controller: 'myCtrl'   
            })

            .when('/cancel', {
                templateUrl: 'pages/cancelticket.html',
                controller: 'myCtrl'
            })
            
             .when('/seatlayout', {
                templateUrl: 'pages/seatlayout.html',
                controller: 'myCtrl'
            })

            .otherwise({ redirectTo: 'home' });
    })

webmodule.controller("myCtrl",function ($scope,$rootScope) {
    
    

});


webmodule.controller("ServiceController", function ($scope, $http, $rootScope,$location) {

 
	
	

    $scope.Loginform = function(isValid){
        
        if (isValid) { 

        	$scope.loginn();  

        }
        }
            
            $scope.loginn=function(){
            	
                $http({
                    method:'POST',
                    url:'http://localhost:8081/Final2/rest/listAll/loginn/'+$scope.Email+'/'+$scope.passw
                }).success(function(data)
                        {
                   
                		if(data==0){
                			alert("user dosen't exist");
                		}
                		else if(data==1){
                			alert("password dosen't match");
                		}
                        
                		else{
                			alert("successful");
                		}
                		
           			
                          
                        
                           
                             
                        });
                
            }



 
    $scope.Registerform = function(isValid){
        
        if (isValid) { 

        	$scope.register();  

        }
        }
            
            $scope.register=function(){
    	
                $http({
                    method:'POST',
                    url:'http://localhost:8081/Final2/rest/listAll/register/'+$scope.fullname+'/'+$scope.phone+'/'+$scope.email+'/'+$scope.pass1+'/'+$scope.gender
                }).success(function(data)
                        {
                    
                        
                	alert("DATA ADDED");
        //    			alert("hello"+data)
                          
                        
                           $rootScope.result = data;
        //                  alert('data' + JSON.stringify($rootScope.result));
                             
                        });
                
            }

		

    $scope.form = {
        source: "",
        destination: "",
        day: "Thursday"

    };
	
    $scope.search=function(){
    	
    	$http({
    		method:'GET',
    		url:'http://localhost:8081/Final2/rest/listAll/search/'+$scope.form.source+'/'+$scope.form.destination+'/'+$scope.form.day
    	}).success(function(data)
    			{
    		
    			
    		
//    			alert("hello"+data)
    			  
    			
    			   $rootScope.result = data;
//                  alert('data' + JSON.stringify($rootScope.result));
    			     
    			});
    	
    }
    
    
$scope.route=function(){
    	
    	$http({
    		method:'GET',
    		url:'http://localhost:8081/Final2/rest/listAll/route/'+$scope.form.source+'/'+$scope.form.destination
    	}).success(function(data)
    			{
    			
    			   $rootScope.routedata = data;
                 
    			     
    			});
    	
    }

    $scope.insertval = {

        userval: "",
        totalseat:"",
        seatno: ""
    } 
    
        $scope.insert=function(){
            
            $http({
                method:'POST',
                url:'http://localhost:8081/Final2/rest/listAll/insert/'+$scope.insertval.userval+'/'+$scope.insertval.totalseat+'/'+$scope.insertval.seatno
            }).success(function(data)
                    {
                        $rootScope.routedata = data;   
                    });
            
        }
    
});
